import time
from . import bannn
from . import head
def starta():
	from colorama import Fore as f
	bannn.starta()
	time.sleep(0.2)
	print(f.LIGHTCYAN_EX+"["+f.LIGHTRED_EX+"@"+f.LIGHTCYAN_EX+"]"+f.LIGHTMAGENTA_EX+" instagram : realshayii")
	time.sleep(0.2)
	input(f.LIGHTBLACK_EX+"Press any key for back to main menu")
	time.sleep(0.8)
	head.starta()
	
	