import pyfiglet
import os
import time
import colorama
def starta():
	os.system("clear")
	text = "smsFucker"
	print(colorama.Fore.LIGHTCYAN_EX+pyfiglet.figlet_format(text)+colorama.Fore.RESET)
	navar = """*===============================================*
*                 smsFucker                     *
*                                               *
*===============================================*"""
	print(colorama.Fore.LIGHTRED_EX+navar+colorama.Fore.RESET)



