import time
import sys
from . import devel
from . import smssender
def starta():
	import time
	from . import devel
	from . import bannn
	from . import smssender
	from colorama import Fore as f
	bannn.starta()
	time.sleep(0.2)
	print(f.LIGHTCYAN_EX+"["+f.LIGHTRED_EX+"#"+f.LIGHTCYAN_EX+"]"+f.LIGHTMAGENTA_EX+" select an option")
	time.sleep(0.2)
	print("\n"+f.LIGHTCYAN_EX+"["+f.LIGHTRED_EX+"1"+f.LIGHTCYAN_EX+"]"+f.LIGHTMAGENTA_EX+" smsFucker")
	time.sleep(0.2)
	print(f.LIGHTCYAN_EX+"["+f.LIGHTRED_EX+"2"+f.LIGHTCYAN_EX+"]"+f.LIGHTMAGENTA_EX+" developer")
	time.sleep(0.2)
	print(f.LIGHTCYAN_EX+"["+f.LIGHTRED_EX+"3"+f.LIGHTCYAN_EX+"]"+f.LIGHTMAGENTA_EX+" Exit"+f.RESET)
	time.sleep(0.2)
	inp = input("\n"+f.LIGHTCYAN_EX+"#"+f.LIGHTRED_EX+"=====> "+f.RESET)
	
	if inp == "1":
		smssender.starta()
	elif inp == "3":
		time.sleep(0.5)
		sys.exit()
	elif inp == "2":
		devel.starta()
	elif inp == "":
		print(f.LIGHTBLACK_EX+"please choose one of the options")
		time.sleep(1)
		sys.exit()
	elif type(inp) != int:
		print(f.LIGHTBLACK_EX+"you should just input number")
		time.sleep(1)
		sys.exit()
	








